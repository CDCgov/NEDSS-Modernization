use master
GO
RESTORE DATABASE [NBS_SRTE] FROM
DISK = N'/var/opt/db-restore/restore.d/NBS_SRTE.bak'
WITH  FILE = 1,
MOVE N'nbs_srte_generic113_Data' TO N'/var/opt/mssql/data/nbs_srte.mdf',
MOVE N'nbs_srte_generic113_Log' TO N'/var/opt/mssql/data/nbs_srte.ldf',  NOUNLOAD,  STATS = 10
GO
RESTORE DATABASE [NBS_ODSE] FROM DISK = N'/var/opt/db-restore/restore.d/NBS_ODSE.bak'
GO